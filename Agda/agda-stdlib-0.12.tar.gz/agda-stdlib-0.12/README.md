agda-stdlib
===========

The Agda standard library. You can browse the source in glorious clickable html here:

https://agda.github.io/agda-stdlib/README.html
